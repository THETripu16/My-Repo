document.addEventListener('scroll', () => {
    var
        st = document.documentElement.scrollTop,
        btn = document.querySelector("#back");
    if (st > 600) {
        btn.style.transition = ".5s";
        btn.style.display = "block"
    } else {
        btn.style.display = "none"
        btn.style.transition = ".5s"
    }
});
